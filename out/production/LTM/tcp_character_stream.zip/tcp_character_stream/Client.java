package tcp_character_stream;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Client {
    public static void main(String[] args) throws IOException {
        String host = "203.162.10.109";
        int port = 2208;

        try (Socket socket = new Socket(host, port)) {
            socket.setSoTimeout(5000);

            BufferedWriter bos = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            BufferedReader bis = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // a. Gui chuoi "studentCode;qCode"
            String sCode = "B22DCCN047";
            String qCode = "2S87BluU";
            String req = sCode + ";" + qCode;
            bos.write(req);
            bos.newLine();
            bos.flush();

            // b. Nhan danh sach cac ten mien tu server
            String domainsLine = bis.readLine();
            String[] domains = domainsLine.split(",\\s*");

            // c. Tim cac domain .edu
            List<String> eduDomains = new ArrayList<>();
            for (String d : domains) {
                if (d.trim().endsWith(".edu")) {
                    eduDomains.add(d.trim());
                }
            }
            String eduList = String.join(", ", eduDomains);

            // Gửi lại cho server
            bos.write(eduList);
            bos.newLine();
            bos.flush();

            // ✅ Không cần gọi close() cho bos, bis nữa.
            // Khi thoát khỏi try, socket sẽ auto đóng,
            // đồng thời đóng luôn cả input/output stream.
            bis.close();
            bos.close();
            socket.close();
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tcp_character_stream;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;

/**
 *
 * @author asus
 */
public class Server {
    private static String randomDomain(Random rand) {
        String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        int len = rand.nextInt(10) + 5; // 5-15 ký tự
        for (int i = 0; i < len; i++) {
            sb.append(chars.charAt(rand.nextInt(chars.length())));
        }
        // chọn hậu tố ngẫu nhiên
        String[] suffixes = {".com", ".vn", ".edu", ".io"};
        return sb.toString() + suffixes[rand.nextInt(suffixes.length)];
    }

    public static void main(String[] args) {
        int port = 2208;
        try (ServerSocket server = new ServerSocket(port)) {
            System.out.println("Server started at port " + port);

            while (true) {
                try (Socket conn = server.accept()) {
                    System.out.println("New connection: " + conn);

                    BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream()));
                    BufferedWriter writer = new BufferedWriter(
                            new OutputStreamWriter(conn.getOutputStream()));

                    // 1. Nhận mã studentCode;qCode
                    String request = reader.readLine();
                    System.out.println("Received request: " + request);

                    // 2. Sinh danh sách domain ngẫu nhiên
                    Random rand = new Random();
                    StringBuilder domains = new StringBuilder();
                    for (int i = 0; i < 10; i++) {
                        domains.append(randomDomain(rand));
                        if (i < 9) domains.append(", ");
                    }
                    String domainList = domains.toString();
                    writer.write(domainList);
                    writer.newLine();
                    writer.flush();
                    System.out.println("Sent domains: " + domainList);

                    // 3. Nhận lại danh sách domain .edu
                    String eduList = reader.readLine();
                    System.out.println("Received EDU domains: " + eduList);

                    System.out.println("Done processing request.\n");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
